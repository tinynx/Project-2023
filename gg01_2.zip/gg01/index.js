var product = [{
    id: 1/1,
    img: 'https://images.unsplash.com/photo-1528822855841-e8bf3134cdc9?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Airy Curtain',
    price: 2599,
    description: 'Cwไไๆำ Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 1/2,
    img: 'https://images.unsplash.com/photo-1539208175673-6b9149754096?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Curtain Gray Knitted Fabric',
    price: 4199,
    description: 'sofa Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 1/3,
    img: 'https://images.unsplash.com/photo-1570427224050-b080ad19e3c4?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Airy Cream Curtain',
    price: 2799,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 1/4,
    img: 'https://images.unsplash.com/photo-1573507811472-909cd17e834d?q=80&w=2080&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Simple Curtain',
    price: 3000,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 1/5,
    img: 'https://images.unsplash.com/photo-1577926866949-c1ed2147d862?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Luxurious Curtain',
    price: 200,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 1/6,
    img: 'https://images.unsplash.com/photo-1530914507926-36d0f98a9f1f?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Transparent white Curtain',
    price: 2199,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 1/7,
    img: 'https://images.unsplash.com/photo-1577926898619-41472eb8471e?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Translucent sugar Curtain',
    price: 1999,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 1/8,
    img: 'https://images.unsplash.com/photo-1621025612922-170474e96e38?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Curtain Taothmil',
    price: 1899,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 1/9,
    img: 'https://images.unsplash.com/photo-1598414381594-18d86505f5d5?q=80&w=2096&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Light orange',
    price: 3199,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Curtain'
}, {
    id: 2/1,
    img: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Dark green Bedsheet',
    price: 1900,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'
}, {
    id: 2/2,
    img: 'https://images.unsplash.com/photo-1540574163026-643ea20ade25?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Brown leather',
    price: 3150,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'
}, {
    id: 2/3,
    img: 'https://images.unsplash.com/photo-1558211583-d26f610c1eb1?q=80&w=2006&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Lemon tea',
    price: 1400,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'
}, {
    id: 2/4,
    img: 'https://plus.unsplash.com/premium_photo-1672136336540-2dd39fd4d1e2?q=80&w=2128&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Medium White',
    price: 1560,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'
}, {
    id: 2/5,
    img: 'https://images.unsplash.com/photo-1484101403633-562f891dc89a?q=80&w=2074&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'bright blue',
    price: 3500,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'
}, {
    id: 2/6,
    img: 'https://images.unsplash.com/photo-1634497885778-152eb6fd543d?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Sparkling gray',
    price: 3499,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'

}, {
    id: 2/7,
    img: 'https://images.unsplash.com/photo-1647221598498-245f6ed6c720?q=80&w=1932&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Matte gray',
    price: 3000,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'

}, {
    id: 2/8,
    img: 'https://images.unsplash.com/photo-1573866926487-a1865558a9cf?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Dark brown leather',
    price: 4999,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'

}, {
    id: 2/9,
    img: 'https://images.unsplash.com/photo-1558898434-af897d9ac0a4?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Orange smoothie',
    price: 2499,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'
}, {
    id: 2/10,
    img: 'https://images.unsplash.com/photo-1512212621149-107ffe572d2f?q=80&w=2080&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Sour Cream',
    price: 2000,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'

}, {
    id: 2/11,
    img: 'https://images.unsplash.com/photo-1549187774-b4e9b0445b41?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Juicy orange leather',
    price: 4100,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'

}, {
    id: 2/12,
    img: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Gray cloth',
    price: 2200,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Sofa'
}, {
    id: 3/1,
    img: 'https://images.unsplash.com/photo-1603087970319-4c90bd58ddeb?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Scott Blue',
    price: 2200,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/2,
    img: 'https://images.unsplash.com/photo-1534973098198-6b2de48816b7?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Wrinkled Bedsheet',
    price: 2600,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/3,
    img: 'https://images.unsplash.com/photo-1542728929-2b5d9a0c8d48?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'White Bedsheet',
    price: 4200,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/4,
    img: 'https://images.unsplash.com/photo-1613395804277-ff52684350ca?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Straight pattern Bedsheet',
    price: 8200,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/5,
    img: 'https://images.unsplash.com/photo-1612280791652-650acbf2bb88?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'DarknedBedsheet',
    price: 7200,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/6,
    img: 'https://plus.unsplash.com/premium_photo-1683888725058-d8a07da8822c?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Light Bedsheet',
    price: 7500,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/7,
    img: 'https://images.unsplash.com/photo-1638878468165-a974415fed4f?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Blue line Bedsheet',
    price: 15900,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/8,
    img: 'https://plus.unsplash.com/premium_photo-1673942750147-87233d9f29d5?q=80&w=1994&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Relex Bedsheet',
    price: 78950,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/9,
    img: 'https://plus.unsplash.com/premium_photo-1664014119716-8428c2300b34?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'RelexBedsheet',
    price: 46000,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/10,
    img: 'https://images.unsplash.com/photo-1630566614083-2bf0cff460b8?q=80&w=1976&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'ModernBedsheet',
    price: 15900,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'
}, {
    id: 3/11,
    img: 'https://images.unsplash.com/photo-1601276174812-63280a55656e?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    name: 'Ori Bedsheet',
    price: 40000,
    description: 'bedsheet Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis aperiam similique quod nemo quaerat impedit!',
    type:  'Bedsheet'


}]

$(document).ready(() => {
    var html = '';
    for (let i = 0; i < product.length; i++) {
        html += `<div onclick="openProductDetail(${i})" class="product-items ${product[i].type}">
                    <img class="product-img" src="${product[i].img}" alt="">
                    <p style="font-size: 1.2vw;">${product[i].name}</p>
                    <p style="font-size: .9vw;">${ numberWithCommas(product[i].price)} THB</p>
                </div>`;
    }
    $("#productlist").html(html);
})


function numberWithCommas(x) {
    x = x.toString();
    var pattern = /(-?\d+)(\d{3})/;
    while (pattern.test(x))
        x = x.replace(pattern, "$1,$2");
    return x;
}

function searchsomething(elem) {
    // console.log('#'+elem.id)
    var value = $('#'+elem.id).val()
    console.log(value)
    
    var html = '';
    for (let i = 0; i < product.length; i++) {
        if( product[i].name.includes(value) ) {
            html += `<div "openProductDetail(${i})" class="product-items ${product[i].type}">
                    <img class="product-img" src="${product[i].img}" alt="">
                    <p style="font-size: 1.2vw;">${product[i].name}</p>
                    <p style="font-size: .9vw;">${ numberWithCommas(product[i].price)} THB</p>
                </div>`;
        }    
    }
    if(html == '') {
        $("#productlist").html(`<p>Not found product</p>`);
    } else {
        $("#productlist").html(html);
    }   

}

function searchproduct(param) {
    console.log(param)
    $(".product-items").css('display', 'none')
    if(param == 'all') {
        $(".product-items").css('display', 'block')
    }
    else {
        $("."+param).css('display', 'block')
    }
}

var productindex = 0;
function openProductDetail(index) {
    productindex = index;
    console.log(productindex)
    $("#modalDesc").css('display', 'flex')
    $("#mdd-img").attr('src', product[index].img);
    $("#mdd-name").text(product[index].name)
    $("#mdd-price").text( numberWithCommas(product[index].price) + ' THB' )
    $("#mdd-desc").text(product[index].description)
}

function closeModal() {
    $(".modal").css('display','none')
}

var cart = [];
function addtocart() {
    var pass = true;

    for (let i = 0; i < cart.length; i++) {
        if( productindex == cart[i].index ) {
            console.log('found same product')
            cart[i].count++;
            pass = false;
        }
        
    }

    if(pass) {
        var obj = {
            index: productindex,
            id: product[productindex].id,
            name: product[productindex].name,
            price: product[productindex].price,
            img: product[productindex].img,
            count: 1
        };
        //console.log(obj)
        cart.push(obj)
    }
    console.log(cart)

    Swal.fire({
        icon: 'success',
        title: 'Add' + product[productindex].name + ' to cart !'
    })
    $("#cartcount").css('display','flex').text(cart.length)
}

function openCart() {
    $('#modalCart').css('display','flex')
    rendercart()
}

function rendercart() {
    if(cart.length > 0) {
        var html = '';
        for (let i = 0; i < cart.length; i++) {
            html += `<div class="cartlist-items">
                        <div class="cartlis-left">
                            <img src="${cart[i].img}" alt="">
                            <div class="cartlist-detail">
                                <p style="font-size: 1.5vw;">${cart[i].name}</p>
                                <p style="font-size: 1.2vw;">${ numberWithCommas(cart[i].price * cart[i].count ) } THB</p>
                            </div>
                        </div>
                        <div class="cartlist-right">
                            <p onclick="deinitems('-', ${i})" class="btnc">-</p>
                            <p id="countitems${i}" style="margin: 0 20px;">${cart[i].count}</p>
                            <p onclick="deinitems('+', ${i})" class="btnc">+</p>
                        </div>
                    </div>`;
        }
        $("#mycart").html(html)
    }
    else {
        $("#mycart").html(`<p>Not found product list</p>`)
    }
}

function deinitems(action, index) {
    if(action == '-') {
        if(cart[index].count > 0) {
            cart[index].count--;
            $("#countitems"+index).text(cart[index].count)

            if(cart[index].count <= 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Are you sure to delete?',
                    showConfirmButton: true,
                    showCancelButton: true,
                    confirmButtonText: 'Delete',
                    cancelButtonText: 'Cancel'
                }).then((res) => {
                    if(res.isConfirmed) {
                        cart.splice(index, 1)
                        console.log(cart)
                        rendercart();
                        $("#cartcount").css('display','flex').text(cart.length)
                        
                        if(cart.length <= 0) {
                            $("#cartcount").css('display','none')
                        } 
                    }
                    else {
                        cart[index].count++;
                        $("#countitems"+index).text(cart[index].count)
                    }
                })
            }
        }
    }
    else if(action =='+') {
        cart[index].count++;
        $("#countitems"+index).text(cart[index].count)
    }
}